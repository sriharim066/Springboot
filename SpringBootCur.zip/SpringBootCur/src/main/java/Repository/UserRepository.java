package Repository;
import org.springframework.data.repository.CrudRepository;
import Entiry.User;
public interface UserRepository extends CrudRepository<User, Integer>{

}
