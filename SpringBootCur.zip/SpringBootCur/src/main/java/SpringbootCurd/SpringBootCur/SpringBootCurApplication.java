package SpringbootCurd.SpringBootCur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCurApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCurApplication.class, args);
	}

}
