package Entiry;
import java.sql.Date;

import javax.persistence.Column;  
import javax.persistence.Entity;  
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table 
public class User {
	@Id  
	@Column  
	private int userid;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public String getUserage() {
		return Userage;
	}
	public void setUserage(String userage) {
		Userage = userage;
	}
	@Column  
	private String username;
	
	@Temporal(TemporalType.DATE)
    private Date birthDate;
	@Column  
	private String Userage;
	
	

}
